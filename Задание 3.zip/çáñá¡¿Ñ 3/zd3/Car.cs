﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zd3
{
    abstract class Car
    {
        double mileage;
        double con_per_km;
        public Car (double mileage, double con_per_km) 
        {
            this.mileage = mileage;
            this.con_per_km = con_per_km;
        }
        public double Mileage 
        {
            get 
            {
                return mileage;
            }
            set 
            {
                mileage = value;
            }
        }
        public double Con_per_km
        {
            get
            {
                return con_per_km;
            }
            set
            {
                con_per_km = value;
            }
        }
        abstract public double Q ();
        abstract public string Info ();


    }
}
